import React from "react";

export const About = () => {
  return (
    <div>
      Lorem ipsum dolor sit amet consectetur, adipisicing elit. Ad
      necessitatibus, aliquid debitis veritatis deserunt numquam, dolore in sint
      ipsa ipsam autem ipsum asperiores optio voluptate animi aperiam corrupti
      ab quae.
    </div>
  );
};
